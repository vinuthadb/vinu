# Project-5-Book-Rep-Customer-Relations-Management
This project updates the CRM HTML page to add some visual style and make it look professional.
